let hours_worked = 8
